<script setup>
import { useAuthStore } from '@/stores/auth'
import { computed } from 'vue'
import AppMenuItem from './AppMenuItem.vue'

const authStore = useAuthStore()

const model = computed(() => {
    const user = authStore.user
    if (!user) return []

    const isAgencyLevel = user.type === 'super_admin' ||
        (user.type === 'staff' && user.parent_id === user.parent_id) // agency staff

    const isSuperAdmin = user.type === 'super_admin'
    const isAgent = user.type === 'agent'
    const isSubAgent = user.type === 'sub_agent'
    const hasPermission = (perm) => authStore.hasPermission(perm)

    const menu = []

    // ─── MAIN ─────────────────────────────────
    menu.push({
        label: 'MAIN',
        items: [
            { label: 'Dashboard', icon: 'pi pi-home', to: '/' }
        ]
    })

    // ─── USER MANAGEMENT ──────────────────────
    // Only show if has user.view permission
    if (hasPermission('user.view') || hasPermission('user.agent_management')) {
        menu.push({
            label: 'USER MANAGEMENT',
            items: [
                { label: 'Users', icon: 'pi pi-users', to: '/users' }
            ]
        })
    }

    // ─── FINANCE (Admin side) ─────────────────
    // Payment/Credit approval — agency level only
    const financeItems = []

    if (hasPermission('finance.approve_payment')) {
        financeItems.push({ label: 'Payment Requests', icon: 'pi pi-credit-card', to: '/payment-requests' })
    }

    if (hasPermission('finance.set_credit_limit')) {
        financeItems.push({ label: 'Credit Requests', icon: 'pi pi-wallet', to: '/credit-requests' })
    }

    if (financeItems.length > 0) {
        menu.push({ label: 'FINANCE', items: financeItems })
    }

    // ─── MY ACCOUNT ───────────────────────────
    const accountItems = [
        { label: 'My Profile', icon: 'pi pi-user', to: '/profile' }
    ]

    // Balance only for users with booking.create (agents/sub-agents)
    // NOT for super_admin or agency staff
    if (hasPermission('booking.create') && !isSuperAdmin) {
        accountItems.push({ label: 'My Balance', icon: 'pi pi-dollar', to: '/profile/balance' })
        accountItems.push({ label: 'My Ledger', icon: 'pi pi-list', to: '/profile/ledger' })
        accountItems.push({ label: 'Payment Requests', icon: 'pi pi-send', to: '/profile/payment-requests' })
        accountItems.push({ label: 'Credit Requests', icon: 'pi pi-plus-circle', to: '/profile/credit-requests' })
    }

    menu.push({ label: 'MY ACCOUNT', items: accountItems })

    return menu
})
</script>

<template>
    <ul class="layout-menu">
        <template v-for="(item, index) in model" :key="item.label + '_' + index">
            <AppMenuItem v-if="!item.separator" :item="item" :index="index" root />
            <li v-else class="menu-separator" />
        </template>
    </ul>
</template>