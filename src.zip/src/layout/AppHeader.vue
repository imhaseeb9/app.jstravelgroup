<script setup>
import AppConfig from '@/layout/AppConfig.vue'
import AppRightMenu from '@/layout/AppRightMenu.vue'
import { useLayout } from '@/layout/composables/layout'
import { useAuthStore } from '@/stores/auth'
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'
import NotificationsDropdown from '../components/layout/NotificationsDropdown.vue'
import ProfileDropdown from '../components/layout/ProfileDropdown.vue'

const route = useRoute()
const authStore = useAuthStore()
const search = ref('')
const rightMenuRef = ref(null)
const rightMenuOpen = ref(false)
const pageTitle = computed(() => route.meta.title || 'Dashboard')

const { layoutConfig, toggleConfigSidebar, toggleMenu } = useLayout()

const userInitials = computed(() => {
    const name = authStore.user?.name || 'U'
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
})
</script>

<template>
    <header class="layout-topbar !z-40">
        <div class="topbar-left">
            <template v-if="layoutConfig.menuMode === 'overlay' || layoutConfig.menuMode === 'static'">
                <button type="button" @click="toggleMenu" class="menu-button">
                    <i class="pi pi-bars" />
                </button>
                <span class="topbar-separator" />
            </template>
            <div class="page-title">{{ pageTitle }}</div>
        </div>

        <div class="topbar-right">
            <IconField>
                <InputIcon class="pi pi-search" />
                <InputText v-model="search" placeholder="Search" />
            </IconField>

            <div class="topbar-actions">
                <button type="button" @click="toggleMenu" class="menu-button menu-button-mobile">
                    <i class="pi pi-bars" />
                </button>

                <button type="button" @click="toggleConfigSidebar" class="app-config-button">
                    <i class="pi pi-cog" />
                </button>

                <AppConfig />

                <!-- Notifications -->
                <div class="relative">
                    <a v-styleclass="{ selector: '@next', enterFromClass: 'hidden', enterActiveClass: 'p-anchored-overlay-enter-active', leaveActiveClass: 'p-anchored-overlay-leave-active', leaveToClass: 'hidden', hideOnOutsideClick: true }">
                        <Button icon="pi pi-bell" severity="secondary" outlined />
                    </a>
                    <div class="absolute hidden min-w-72 top-auto right-0 z-20 mt-2">
                        <NotificationsDropdown class="w-full sm:w-[22rem]" />
                    </div>
                </div>

                <!-- User Avatar with initials -->
                <div class="relative">
                    
                        v-styleclass="{ selector: '@next', enterFromClass: 'hidden', enterActiveClass: 'p-anchored-overlay-enter-active', leaveActiveClass: 'p-anchored-overlay-leave-active', leaveToClass: 'hidden', hideOnOutsideClick: true }"
                        class="flex items-center"
                    >
                        <div class="w-9 h-9 rounded-md bg-primary-500 flex items-center justify-center cursor-pointer text-white font-bold text-sm">
                            {{ userInitials }}
                        </div>
                    </a>
                    <div class="absolute hidden top-full right-0 mt-2 z-20">
                        <ProfileDropdown class="w-52" />
                    </div>
                </div>

                <Button @click="toggleRightMenu" icon="pi pi-align-right" severity="secondary" outlined />
                <AppRightMenu ref="rightMenuRef" :open="rightMenuOpen" @toggle="(value) => (rightMenuOpen = value)" />
            </div>
        </div>
    </header>
</template>